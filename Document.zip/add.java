public class add
{
	public static void main(String[] args)
	{
	int a=10, b=20, sum;
	sum = a+b;
	System.out.println("Addition of number is :"+sum);
}
}