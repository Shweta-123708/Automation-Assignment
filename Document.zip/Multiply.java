public class Multiply
{
	public static void main(String[] args)
	{
	int a=10, b=20, mul;
	mul = a*b;
	System.out.println("Addition of number is :"+mul);
}
}