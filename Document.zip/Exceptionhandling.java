import java.util.Scanner;

public class Exceptionhandling{
	public static void main(String[] args){
	 try{ 
		 try {
	     System.out.println("going to divide by 0");    
	     int b =39/0;    
	   }   
	    catch(ArithmeticException e)  
	    {  
	      System.out.println(e);  
	    }
		 try {
		    	String s=null;
		    	System.out.println(s.length());
		    }
		    catch(NullPointerException e){
		    	System.out.println(e);
		    }
		 try {
		    	int n;  
			Scanner sc=new Scanner(System.in);  
			System.out.print("Enter the number of elements you want to store: ");  
			n=sc.nextInt();  
			int[] array = new int[n];  
			System.out.println("Enter the elements of the array: ");  
			for(int i=0; i<n; i++) 
			{     
				array[i]=sc.nextInt();  
				 
		  }
			System.out.println(array[n+1]);
		    }
			catch(ArrayIndexOutOfBoundsException e)  
		    {  
		       System.out.println(e);  
		    }
}
	 finally {  
	        System.out.println("finally block is always executed");  
	      }    
	}
}