public class FirstProgram{
	public static void main(String arg[])
	{
		System.out.println("Hello world");
		int a=10, b=20, sum, diff, multiply, divide;
		sum = a+b;
		diff = b-a;
		multiply = a*b;
		divide = b/a;
	    System.out.println("sum of these numbers: "+sum+ "\n"+ "Difference of these numbers:"+diff+"\n"+"Multiplication of these number"+multiply);
	}
}
