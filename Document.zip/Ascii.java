public class Ascii
{
	public static void main(String[] args)
	{
		char c= 's';
		int ascii = c;
		System.out.println("The ASCII value of "+c+"is:"+ascii);
	}
}