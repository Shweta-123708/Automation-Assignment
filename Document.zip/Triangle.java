public class Triangle
{
	public static void main(String[] args)
	{
	int b= 8, h=5, area;
	area = (b*h)/2;
	System.out.println("Area of the triangle is :"+area);
}
}