public class Check
{
	public static void main(String[] args)
	{
		int number= 210;
		if(number>0)
		{
			System.out.println(number+" is a positive number");
		}
		else
		{
			System.out.println(number+" is a negative number");
		}
	}
}