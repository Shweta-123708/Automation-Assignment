public class Main

{

public static void main(String[] args)

{

    Bank A = new BankA();

    A.getBalance();

    Bank B= new BankB();

    B.getBalance();

    Bank C = new BankC();

    C.getBalance();

}

}