public class calculateBalance {
	public static void main(String[] args){

		   BankA Balance1 = new BankA();

		   Balance1.getBalance();

		   BankB Balance2 = new BankB();

		   Balance2.getBalance();

		   BankC Balance3 = new BankC();

		   Balance3.getBalance();

		   }
}

