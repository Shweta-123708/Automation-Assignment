import java.util.*;

abstract class Banking

{

   abstract void getBalance1();

protected abstract void getBalance();

}

abstract class BankA extends Banking

{

   void getBalance1()

   {

       System.out.println("Money deposited in Bank A is $1000");

   }

}

abstract class BankB extends Banking

{

   void getBalance1()

   {

       System.out.println("Money deposited in Bank B is $1500");

   }

}

abstract class BankC extends Banking

{

   void getBalance1()

   {

       System.out.println("Money deposited in Bank C is $2000");

   }

}
 


