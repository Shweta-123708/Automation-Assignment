import java.lang.*;
import java.io.*;
import java.util.*;
public class StringCheck{
	public static void main(String[] args)
    {
		System.out.println("Enter the string");
		Scanner sc= new Scanner(System.in);
		String s=sc.nextLine();
 
        StringBuilder input1 = new StringBuilder();
        input1.append(s);
        input1.reverse();
        System.out.println(input1);
    }
	
}