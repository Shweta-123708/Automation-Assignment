import java.util.*;

public class Factorial{
	public static void main(String[] args)
	{
		System.out.println("Enter a number");
		Scanner sc= new Scanner(System.in);
		int number=sc.nextInt();
		int fact=1;
		while(number>0)
		{
		fact=fact*number;
		number=number-1;
	}
		System.out.println("Factorial is" +" "+fact);
}
}