 class Clock1
	 {
		int hours, minutes, seconds;
		Clock1(int h, int m, int s)
		{
		hours=h;
		minutes=m;
		seconds=s;
	 }
		void isTimeValid()
		{
			if(hours>=0 && hours<24  && minutes>=0 && minutes<60 && seconds>=0 && seconds<60)
				
			{
				System.out.println("TIME IS VALID");
			}
		
		else
		{
			System.out.println("TIME IS INVALID");
		}
		}
		void SetTimeMode()
		{
			if(hours<12)
			{
				System.out.println("Time="+hours+":"+minutes+":"+seconds+"AM");
			}
			else
			{
				hours=hours-12;
				System.out.println("Time="+hours+":"+minutes+":"+seconds+"PM");
			}
		}
	 }

	    
	    
	   