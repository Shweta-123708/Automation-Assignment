import java.util.*;
public class ArrayListDemo3 {
	public static void main(String[] args) {
		  ArrayList<String> list_Strings = new ArrayList<String>();
		  list_Strings.add("Red");
		  list_Strings.add("Green");
		  list_Strings.add("Orange");
		  list_Strings.add("White");
		  list_Strings.add("Black");
		  System.out.println(list_Strings);
		  System.out.println("List before Shuffle : "+list_Strings);  
          Collections.shuffle(list_Strings);  
          System.out.println("List after shuffle : "+list_Strings);  
}
}

