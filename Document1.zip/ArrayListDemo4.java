import java.util.*;
public class ArrayListDemo4 {
	public static void main(String[] args) {
	  ArrayList<String> list_Strings = new ArrayList<String>();
	  list_Strings.add("Red");
	  list_Strings.add("Green");
	  list_Strings.add("Orange");
	  list_Strings.add("White");
	  list_Strings.add("Black");
	  System.out.println(list_Strings);
	  if(list_Strings.isEmpty()) {
          System.out.println("ArrayList is empty.");
      } else {
          System.out.println("ArrayList is not empty.");
      }

}
}