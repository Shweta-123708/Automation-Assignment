import java.util.*;
public class LinkedListDemo4 {
	public static void main(String[] args) {
	     LinkedList<String> l_list = new LinkedList<String>();
	          l_list.add("Red");
	          l_list.add("Green");
	          l_list.add("Black");
	          l_list.add("White");
	          l_list.add("Pink");
	          l_list.add("Yellow");
	          Iterator it = l_list.iterator();
	          while(it.hasNext()){
	              System.out.print(it.next() + " ");
	          }

}
}